"""
O365_python_email client
A Python email client for Exchange Online
"""


__version__ = "0.1.0"
__author__  = "Brent Kimberley"
__credits__ = "Regional Municipality of Durham"

