# O365_python_email_client
O365 Python email client

Azure_AD.json file schema
{
    "appclientID":"<someAppClientID>"
   ,"tenantID":"<someTenantID>"
}
